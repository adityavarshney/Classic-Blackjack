
/**
 * Write a description of class PlayGame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PlayGame extends Table
{
    public void play(){
        while(true){
            PlayGame t = new PlayGame();
        }
    }
}
